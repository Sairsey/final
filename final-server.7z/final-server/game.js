var util = require("util"),
    io = require("socket.io");
var socket,
    players,
    numOfPlayers = 0;
function init() {
    players = [];
}

init();

socket = io.listen(8000);

socket.configure(function() {
    socket.set("transports", ["websocket"]);
    socket.set("log level", 2);
});

setEventHandlers();

function setEventHandlers() {
    socket.sockets.on("connection", check);
}

function check(client) {
    util.log("New player has connected: " + client.id);
    client.on("disconnect", onClientDisconnect);
    client.on("new player", onNewPlayer);
    client.on("move player", onMovePlayer);
};


function onClientDisconnect() {
    util.log("Player has disconnected: " + this.id);
    numOfPlayers--;
}

function onNewPlayer(data) {
    players[numOfPlayers] = data;
    numOfPlayers++;
}

function onMovePlayer(data) {
    players[numOfPlayers].pos.x = data.posx;
    players[numOfPlayers].pos.y = data.posy;
    players[numOfPlayers].pos.z = data.posz;
    players[numOfPlayers].way = data.way;
    players[numOfPlayers].period = data.period;
    socket.emit('update positions', players);
}
