var io = require("socket.io")(1488);
var players,
    numOfPlayers = 0;
function init() {
    players = [];
    players[0] = new Object();
}

init();
setEventHandlers();

function setEventHandlers() {
    io.on("connection", check);
}

function check(client) {
    numOfPlayers++;
    client.emit("add_player2", {data: numOfPlayers, players: players});
    console.log("New player has connected: " + client.id);
    client.emit("add_player", {data: numOfPlayers, players: players});
    client.on("disconnect", onClientDisconnect);
    client.on("new player", function (data) {
            players[data.num] = data;
            client.broadcast.emit("add new player", data);
        });
    client.on("move player", function (data) {
        players[data.num].posx = data.posx;
        players[data.num].posy = data.posy;
        players[data.num].posz = data.posz;
        players[data.num].way = data.way;
        players[data.num].period = data.period;
        client.broadcast.emit('update positions', data);
    });

}


function onClientDisconnect() {
    numOfPlayers--;
    console.log("Player has disconnected: " + this.id);
}

